"""
app.py
------
AI 投資樹洞 (AI Investment Companion) - Streamlit 主應用
核心商業目標：透過獲取使用者真實持股，以 AI 進行客製化心理陪伴與風險診斷
"""

import streamlit as st
import pandas as pd
import re
from datetime import datetime
from data_processor import get_processor
from bedrock_service import get_bedrock_service

# ===== 頁面設定 =====
st.set_page_config(
    page_title="AI 投資樹洞 | AI Investment Companion",
    page_icon="🌳",
    layout="wide",
    initial_sidebar_state="collapsed",
)

# ===== 自定義 CSS =====
st.markdown("""
<style>
    .main-header {
        text-align: center;
        padding: 1rem 0;
    }
    .step-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 0.8rem 1.5rem;
        border-radius: 10px;
        color: white;
        margin-bottom: 1rem;
    }
    .metric-card {
        background: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #667eea;
        margin: 0.5rem 0;
    }
    .success-box {
        background: #d4edda;
        border: 1px solid #c3e6cb;
        padding: 1rem;
        border-radius: 8px;
    }
    .warning-box {
        background: #fff3cd;
        border: 1px solid #ffc107;
        padding: 1rem;
        border-radius: 8px;
    }
</style>
""", unsafe_allow_html=True)


# ===== 初始化 Session State =====
def init_session_state():
    defaults = {
        "current_step": 1,
        "holdings": [],  # 持股清單 [{stock_id, cost, shares, buy_date}]
        "ai_contexts": [],  # AI 上下文列表
        "ai_responses": [],  # AI 回覆列表
        "ocr_result": None,
    }
    for key, val in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = val


init_session_state()


# ===== OCR 模擬模組 =====
def mock_ocr_parse(uploaded_image) -> list:
    """
    模擬 OCR 解析看盤 App 截圖
    實際環境中使用 easyocr 或其他 OCR 引擎
    """
    try:
        import easyocr
        import numpy as np
        from PIL import Image

        reader = easyocr.Reader(["ch_tra", "en"])
        image = Image.open(uploaded_image)
        img_array = np.array(image)
        results = reader.readtext(img_array)

        # 嘗試解析股票代號、成本、股數的模式
        parsed = []
        text_lines = [r[1] for r in results]
        full_text = " ".join(text_lines)

        # 尋找股票代號模式（4位數字）
        stock_ids = re.findall(r"\b(\d{4})\b", full_text)
        # 尋找金額模式
        prices = re.findall(r"(\d+\.?\d*)", full_text)

        if stock_ids:
            parsed.append({
                "stock_id": stock_ids[0],
                "cost": float(prices[1]) if len(prices) > 1 else 0,
                "shares": int(float(prices[2]) * 1000) if len(prices) > 2 else 1000,
            })
        return parsed

    except ImportError:
        # EasyOCR 未安裝，使用 Mock 模擬結果
        st.info("📌 EasyOCR 未安裝，使用模擬 OCR 結果展示功能")
        return [
            {"stock_id": "0050", "cost": 180.5, "shares": 5000},
            {"stock_id": "2330", "cost": 580.0, "shares": 2000},
        ]


# ===== 電子對帳單解析模組 =====
def parse_statement(uploaded_file) -> list:
    """
    解析電子對帳單（PDF/HTML）
    實際環境中使用 pdfplumber，此處用正則表達式模擬
    """
    parsed_holdings = []

    if uploaded_file is None:
        return parsed_holdings

    file_type = uploaded_file.name.split(".")[-1].lower()

    try:
        if file_type == "pdf":
            try:
                import pdfplumber

                with pdfplumber.open(uploaded_file) as pdf:
                    full_text = ""
                    for page in pdf.pages:
                        full_text += page.extract_text() or ""

                    # 解析表格式對帳單
                    # 常見格式：股票代號 股票名稱 股數 成本 現價 ...
                    lines = full_text.split("\n")
                    for line in lines:
                        # 匹配：4位代號 + 名稱 + 數字（股數、成本等）
                        match = re.search(
                            r"(\d{4,6})\s+\S+\s+(\d[\d,]*)\s+([\d.]+)",
                            line,
                        )
                        if match:
                            parsed_holdings.append({
                                "stock_id": match.group(1),
                                "shares": int(match.group(2).replace(",", "")),
                                "cost": float(match.group(3)),
                            })

            except ImportError:
                # pdfplumber 未安裝
                st.info("📌 pdfplumber 未安裝，使用模擬解析結果")
                parsed_holdings = _mock_statement_result()

        elif file_type in ["html", "htm"]:
            content = uploaded_file.read().decode("utf-8", errors="ignore")
            # 嘗試用正則解析 HTML 表格中的持股資料
            rows = re.findall(
                r"<td[^>]*>(\d{4,6})</td>\s*<td[^>]*>([^<]+)</td>\s*<td[^>]*>([\d,]+)</td>\s*<td[^>]*>([\d.]+)</td>",
                content,
            )
            for row in rows:
                parsed_holdings.append({
                    "stock_id": row[0],
                    "shares": int(row[2].replace(",", "")),
                    "cost": float(row[3]),
                })

            if not parsed_holdings:
                st.info("📌 無法從 HTML 中解析到持股資料，使用模擬結果")
                parsed_holdings = _mock_statement_result()

        else:
            # CSV 或其他格式
            try:
                df = pd.read_csv(uploaded_file)
                # 嘗試識別欄位
                for _, row in df.iterrows():
                    stock_id = str(row.iloc[0]).strip()
                    if re.match(r"^\d{4,6}$", stock_id):
                        parsed_holdings.append({
                            "stock_id": stock_id,
                            "shares": int(row.iloc[2]) if len(row) > 2 else 1000,
                            "cost": float(row.iloc[3]) if len(row) > 3 else 0,
                        })
            except Exception:
                parsed_holdings = _mock_statement_result()

    except Exception as e:
        st.warning(f"解析發生錯誤：{e}，使用模擬資料")
        parsed_holdings = _mock_statement_result()

    return parsed_holdings


def _mock_statement_result() -> list:
    """模擬對帳單解析結果"""
    return [
        {"stock_id": "0050", "cost": 185.0, "shares": 3000},
        {"stock_id": "0056", "cost": 35.5, "shares": 10000},
        {"stock_id": "00878", "cost": 20.0, "shares": 15000},
    ]


# ===== 主介面 =====
def main():
    # 標題區
    st.markdown("""
    <div class="main-header">
        <h1>🌳 AI 投資樹洞</h1>
        <p style="font-size: 1.1rem; color: #666;">
            AI Investment Companion — 你的專屬投資陪伴教練
        </p>
        <p style="font-size: 0.9rem; color: #999;">
            📅 系統時間基準：2025/12/31 ｜ 資料來源：CMoney
        </p>
    </div>
    """, unsafe_allow_html=True)

    st.divider()

    # 步驟指示器
    col1, col2, col3 = st.columns(3)
    steps = ["📥 持股導入", "🔬 數據分析", "💬 AI 診斷"]
    for i, (col, step) in enumerate(zip([col1, col2, col3], steps), 1):
        with col:
            if i == st.session_state.current_step:
                st.markdown(f"**➤ 步驟 {i}：{step}**")
            elif i < st.session_state.current_step:
                st.markdown(f"✅ 步驟 {i}：{step}")
            else:
                st.markdown(f"⬜ 步驟 {i}：{step}")

    st.divider()

    # 根據當前步驟顯示對應畫面
    if st.session_state.current_step == 1:
        render_step1_input()
    elif st.session_state.current_step == 2:
        render_step2_analysis()
    elif st.session_state.current_step == 3:
        render_step3_output()


# ===== 步驟 1：持股導入 =====
def render_step1_input():
    st.markdown('<div class="step-header"><h3>📥 步驟 1：持股導入與健診入口</h3></div>', unsafe_allow_html=True)
    st.markdown("請選擇一種方式導入你的真實持股資料，讓 AI 為你進行專屬健診。")

    tab1, tab2, tab3 = st.tabs(["✍️ 手動輸入", "📸 截圖 OCR 匯入", "📄 電子對帳單解析"])

    # --- Tab 1: 手動輸入 ---
    with tab1:
        st.markdown("#### 手動輸入持股資料")

        processor = get_processor()
        available_stocks = processor.get_available_stocks()

        with st.form("manual_input_form"):
            col1, col2 = st.columns(2)

            with col1:
                stock_input = st.text_input(
                    "股票代號",
                    placeholder="例如：0050",
                    help="請輸入 4~6 位數的股票代號",
                )
                cost_input = st.number_input(
                    "買進成本（元）",
                    min_value=0.0,
                    step=0.1,
                    format="%.2f",
                    help="每股的平均買進成本",
                )

            with col2:
                shares_input = st.number_input(
                    "持有股數",
                    min_value=0,
                    step=1000,
                    value=1000,
                    help="持有的總股數",
                )
                buy_date_input = st.date_input(
                    "買進日期",
                    value=datetime(2025, 6, 15),
                    min_value=datetime(2020, 1, 1),
                    max_value=datetime(2025, 12, 31),
                )

            submitted = st.form_submit_button("➕ 加入持股清單", use_container_width=True)

            if submitted and stock_input:
                stock_id = stock_input.strip()
                # 驗證股票是否存在於資料庫
                if stock_id in available_stocks["股票代號"].values:
                    new_holding = {
                        "stock_id": stock_id,
                        "cost": cost_input,
                        "shares": shares_input,
                        "buy_date": buy_date_input.strftime("%Y-%m-%d"),
                    }
                    st.session_state.holdings.append(new_holding)
                    st.success(f"✅ 已加入 {stock_id} 到持股清單")
                else:
                    st.error(f"❌ 股票代號 {stock_id} 不在資料庫中（本 Demo 涵蓋 300 檔示範標的）")

        # 顯示可用股票提示
        with st.expander("🔍 查看資料庫中可用的股票代號"):
            st.dataframe(
                available_stocks[["股票代號", "股票名稱", "產業"]],
                use_container_width=True,
                height=300,
            )

    # --- Tab 2: OCR 匯入 ---
    with tab2:
        st.markdown("#### 📸 截圖 OCR 匯入")
        st.markdown("上傳你的看盤 App 庫存截圖，AI 將自動辨識股票代號、成本與股數。")

        uploaded_image = st.file_uploader(
            "上傳庫存截圖",
            type=["png", "jpg", "jpeg"],
            key="ocr_upload",
        )

        if uploaded_image is not None:
            st.image(uploaded_image, caption="已上傳的截圖", width=400)

            if st.button("🔍 開始 OCR 辨識", key="ocr_btn"):
                with st.spinner("正在辨識圖片中的文字..."):
                    ocr_results = mock_ocr_parse(uploaded_image)

                if ocr_results:
                    st.success(f"✅ 辨識完成，找到 {len(ocr_results)} 筆持股資料")
                    for item in ocr_results:
                        st.markdown(f"- 代號：**{item['stock_id']}**，成本：{item['cost']}，股數：{item['shares']}")

                    if st.button("📥 全部加入持股清單", key="ocr_add_all"):
                        for item in ocr_results:
                            st.session_state.holdings.append({
                                "stock_id": item["stock_id"],
                                "cost": item["cost"],
                                "shares": item["shares"],
                                "buy_date": "2025-06-01",
                            })
                        st.rerun()
                else:
                    st.warning("未能從截圖中辨識到持股資料")

    # --- Tab 3: 電子對帳單 ---
    with tab3:
        st.markdown("#### 📄 電子對帳單解析")
        st.markdown("上傳券商寄送的電子對帳單（PDF/HTML/CSV），系統將自動解析你的庫存資料。")

        uploaded_statement = st.file_uploader(
            "上傳電子對帳單",
            type=["pdf", "html", "htm", "csv"],
            key="statement_upload",
        )

        if uploaded_statement is not None:
            if st.button("📊 解析對帳單", key="parse_btn"):
                with st.spinner("正在解析對帳單..."):
                    parsed = parse_statement(uploaded_statement)

                if parsed:
                    st.success(f"✅ 解析完成，找到 {len(parsed)} 筆持股資料")

                    df_parsed = pd.DataFrame(parsed)
                    df_parsed.columns = ["股票代號", "買進成本", "持有股數"]
                    st.dataframe(df_parsed, use_container_width=True)

                    if st.button("📥 全部加入持股清單", key="statement_add_all"):
                        for item in parsed:
                            st.session_state.holdings.append({
                                "stock_id": item["stock_id"],
                                "cost": item["cost"],
                                "shares": item["shares"],
                                "buy_date": "2025-01-01",
                            })
                        st.rerun()
                else:
                    st.warning("未能從對帳單中解析到持股資料")

    # --- 持股清單顯示 ---
    st.divider()
    st.markdown("### 📋 目前持股清單")

    if st.session_state.holdings:
        df_holdings = pd.DataFrame(st.session_state.holdings)
        df_holdings.columns = ["股票代號", "買進成本", "持有股數", "買進日期"]
        st.dataframe(df_holdings, use_container_width=True)

        col1, col2 = st.columns([1, 1])
        with col1:
            if st.button("🗑️ 清空持股清單", use_container_width=True):
                st.session_state.holdings = []
                st.rerun()
        with col2:
            if st.button("🚀 開始 AI 健診", type="primary", use_container_width=True):
                st.session_state.current_step = 2
                st.rerun()
    else:
        st.info("尚未加入任何持股，請使用上方任一方式導入你的持股資料。")


# ===== 步驟 2：數據分析 =====
def render_step2_analysis():
    st.markdown('<div class="step-header"><h3>🔬 步驟 2：後端數據分析與 RAG Context 打包</h3></div>', unsafe_allow_html=True)

    processor = get_processor()
    holdings = st.session_state.holdings

    if not holdings:
        st.warning("沒有持股資料，請返回步驟 1 加入持股。")
        if st.button("⬅️ 返回步驟 1"):
            st.session_state.current_step = 1
            st.rerun()
        return

    st.markdown("正在為你的每一檔持股查詢最新數據、計算損益與社群情緒...")

    ai_contexts = []
    progress_bar = st.progress(0)

    for idx, holding in enumerate(holdings):
        progress_bar.progress((idx + 1) / len(holdings))
        stock_id = holding["stock_id"]

        context = processor.build_ai_context(
            stock_id=stock_id,
            cost=holding["cost"],
            shares=holding["shares"],
            buy_date=holding.get("buy_date", ""),
        )

        if context:
            ai_contexts.append(context)

    progress_bar.empty()

    if not ai_contexts:
        st.error("❌ 無法取得任何持股的數據，請確認股票代號是否正確。")
        if st.button("⬅️ 返回步驟 1"):
            st.session_state.current_step = 1
            st.rerun()
        return

    # 儲存到 session state
    st.session_state.ai_contexts = ai_contexts

    # 展示分析結果
    st.success(f"✅ 已完成 {len(ai_contexts)} 檔持股的數據分析")

    for ctx in ai_contexts:
        with st.expander(f"📊 {ctx['股票名稱']} ({ctx['股票代號']}) - 數據摘要", expanded=True):
            col1, col2, col3, col4 = st.columns(4)

            with col1:
                pnl = ctx["損益百分比"]
                if pnl is not None:
                    delta_color = "normal" if pnl >= 0 else "inverse"
                    st.metric("損益", f"{pnl}%", delta=f"{pnl}%", delta_color=delta_color)
                else:
                    st.metric("損益", "N/A")

            with col2:
                st.metric("收盤價 (12/31)", f"{ctx['收盤價']} 元" if ctx["收盤價"] else "N/A")

            with col3:
                bp = ctx["買點分位"]
                st.metric("買點分位", f"{bp}%" if bp is not None else "N/A")

            with col4:
                dy = ctx["連續配息年數"]
                st.metric("連續配息", f"{int(dy)} 年" if dy else "N/A")

            # 社群情緒
            st.markdown("**📢 社群情緒 (2025/12/31)**")
            scol1, scol2, scol3, scol4 = st.columns(4)
            with scol1:
                st.metric("發文數", ctx["發文則數"])
            with scol2:
                st.metric("看多", ctx["看多發文"])
            with scol3:
                st.metric("看空", ctx["看空發文"])
            with scol4:
                ratio = ctx["多空比"]
                if ratio == float("inf"):
                    st.metric("多空比", "全看多")
                elif ratio is not None:
                    st.metric("多空比", f"{ratio}")
                else:
                    st.metric("多空比", "N/A")

    st.divider()

    # AI Context 預覽
    with st.expander("🧠 AI 理解包（Prompt Context）預覽"):
        for ctx in ai_contexts:
            st.json(ctx)

    # 進入下一步
    col1, col2 = st.columns([1, 1])
    with col1:
        if st.button("⬅️ 返回修改持股", use_container_width=True):
            st.session_state.current_step = 1
            st.rerun()
    with col2:
        if st.button("🤖 送出 AI 陪伴診斷", type="primary", use_container_width=True):
            st.session_state.current_step = 3
            st.rerun()


# ===== 步驟 3：AI 診斷輸出 =====
def render_step3_output():
    st.markdown('<div class="step-header"><h3>💬 步驟 3：AI 陪伴診斷報告</h3></div>', unsafe_allow_html=True)

    ai_contexts = st.session_state.ai_contexts

    if not ai_contexts:
        st.warning("沒有分析數據，請返回步驟 1。")
        if st.button("⬅️ 返回步驟 1"):
            st.session_state.current_step = 1
            st.rerun()
        return

    bedrock = get_bedrock_service()

    st.markdown("🌳 **AI 投資樹洞正在為你的每一檔持股進行深度陪伴診斷...**")
    st.markdown("---")

    # 逐檔進行 AI 診斷
    for idx, ctx in enumerate(ai_contexts):
        st.markdown(f"### 🔮 {ctx['股票名稱']} ({ctx['股票代號']})")

        # 基本數據卡片
        col1, col2, col3 = st.columns(3)
        with col1:
            pnl = ctx["損益百分比"]
            color = "🟢" if pnl and pnl >= 0 else "🔴"
            st.markdown(f"{color} 損益：**{pnl}%**" if pnl else "損益：N/A")
        with col2:
            st.markdown(f"💰 成本：**{ctx['買進成本']}** → 現價：**{ctx['收盤價']}**")
        with col3:
            st.markdown(f"📊 買點分位：**{ctx['買點分位']}%**" if ctx["買點分位"] else "")

        # AI 回覆
        with st.spinner(f"AI 正在分析 {ctx['股票名稱']}..."):
            response = bedrock.diagnose(ctx)

        # 以聊天氣泡風格顯示
        with st.chat_message("assistant", avatar="🌳"):
            st.markdown(response)

        st.markdown("---")

    # 底部操作區
    st.markdown("### 🛡️ 下一步行動")
    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("🔄 重新診斷", use_container_width=True):
            st.session_state.current_step = 2
            st.rerun()
    with col2:
        if st.button("📥 修改持股", use_container_width=True):
            st.session_state.current_step = 1
            st.rerun()
    with col3:
        if st.button("🛡️ 開啟持股防護罩（訂閱）", type="primary", use_container_width=True):
            st.balloons()
            st.success("🎉 恭喜你！已開啟持股防護罩，我們會在關鍵時刻通知你。")
            st.markdown("""
            **你將收到以下警示通知：**
            - 📈 股價突破年度新高/新低時
            - 🏦 法人連續大量買賣超時
            - 💬 社群情緒劇烈變化時
            - 📅 除息日前 7 天提醒
            """)


# ===== 側邊欄 =====
def render_sidebar():
    with st.sidebar:
        st.markdown("### ⚙️ 系統資訊")
        st.markdown("**系統時間基準：** 2025/12/31")
        st.markdown("**資料來源：** CMoney")
        st.markdown("**涵蓋標的：** 300 檔示範股票")
        st.markdown("**AI 模型：** Claude 3 (AWS Bedrock)")

        st.divider()

        st.markdown("### 📌 使用說明")
        st.markdown("""
        1. **導入持股** - 手動輸入、OCR 或對帳單
        2. **數據分析** - 自動查詢行情與社群情緒
        3. **AI 診斷** - 獲得個人化陪伴分析
        """)

        st.divider()

        st.markdown("### ⚠️ 免責聲明")
        st.caption(
            "本服務僅提供數據分析與心理陪伴，不構成任何投資建議。"
            "投資有風險，決策請自行判斷。"
        )

        st.divider()
        if st.button("🔄 重置應用", use_container_width=True):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()


# ===== 啟動 =====
if __name__ == "__main__":
    render_sidebar()
    main()
