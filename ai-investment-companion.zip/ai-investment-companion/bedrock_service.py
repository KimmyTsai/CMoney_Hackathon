"""
bedrock_service.py
------------------
AI 投資樹洞 - AWS Bedrock 串接模組
使用 boto3 呼叫 Claude 3 模型進行陪伴診斷
"""

import json
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

# Bedrock 設定
BEDROCK_REGION = "us-east-1"
MODEL_ID = "anthropic.claude-3-sonnet-20240229-v1:0"
MAX_TOKENS = 1024

# Prompt 範本
PROMPT_TEMPLATE = """你是一位極具同理心、溫暖且專業的「AI 投資陪伴教練」。

現在有一位用戶向你敞開了他的真實庫存，他目前的持股狀態如下：

- 持有股票：{stock_name} ({stock_id})
- 用戶買進成本：{cost} 元，當前(2025/12/31)收盤價：{closing_price} 元
- 目前用戶損益：{pnl_pct}%
- 該股在 2025 的買點分位：{buy_point_pct}% (0代表全年最低，100代表全年最高)
- 連續配息年數：{dividend_years} 年
- 今日(2025/12/31)社群討論熱度：發文 {post_count} 則，社群多空比：{sentiment_ratio}

請你根據這些數據，針對以下「六個維度」進行深度陪伴診斷：
1. 投資風格 2. 資產配置 3. 集中風險 4. 投資習慣 5. 常見錯誤 6. 決策焦慮

【法遵合規限制 (極重要)】：
你絕對不能給予任何具體的「買進、賣出、加碼、減碼」投資建議，以避免違反投顧法規。你必須站在陪伴與數據分析的角度，解讀他此刻的焦慮。例如：若他買在山頂(買點分位高)，請強調該股連續配息的歷史來安撫他，並用今日社群情緒解釋為什麼大家今天都在慌亂。

請以有溫度、口語化且精準的繁體中文回答，總字數控制在 300 字以內，並在最後設計一個「開啟持股防護罩（訂閱警示）」的文案引導，吸引他留下。"""


class BedrockService:
    """AWS Bedrock 服務封裝"""

    def __init__(self, region: str = BEDROCK_REGION, model_id: str = MODEL_ID):
        self.region = region
        self.model_id = model_id
        self._client = None

    @property
    def client(self):
        """Lazy initialization of Bedrock Runtime client"""
        if self._client is None:
            self._client = boto3.client(
                service_name="bedrock-runtime",
                region_name=self.region,
            )
        return self._client

    def build_prompt(self, context: dict) -> str:
        """根據數據上下文構建完整 Prompt"""
        # 處理多空比顯示
        sentiment_ratio = context.get("多空比")
        if sentiment_ratio is None:
            ratio_display = "無資料"
        elif sentiment_ratio == float("inf"):
            ratio_display = "全看多（無看空發文）"
        else:
            ratio_display = f"{sentiment_ratio}"

        prompt = PROMPT_TEMPLATE.format(
            stock_name=context.get("股票名稱", "未知"),
            stock_id=context.get("股票代號", ""),
            cost=context.get("買進成本", 0),
            closing_price=context.get("收盤價", "N/A"),
            pnl_pct=context.get("損益百分比", "N/A"),
            buy_point_pct=context.get("買點分位", "N/A"),
            dividend_years=context.get("連續配息年數", "N/A"),
            post_count=context.get("發文則數", 0),
            sentiment_ratio=ratio_display,
        )
        return prompt

    def invoke_model(self, prompt: str) -> str:
        """
        呼叫 AWS Bedrock Claude 3 模型
        使用 Messages API 格式
        """
        try:
            body = json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": MAX_TOKENS,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt,
                    }
                ],
                "temperature": 0.7,
                "top_p": 0.9,
            })

            response = self.client.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=body,
            )

            response_body = json.loads(response["body"].read())
            # Claude 3 Messages API 回傳格式
            return response_body["content"][0]["text"]

        except NoCredentialsError:
            return self._generate_fallback_response(prompt)
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "AccessDeniedException":
                return self._generate_fallback_response(prompt)
            raise e
        except Exception as e:
            return self._generate_fallback_response(prompt, str(e))

    def diagnose(self, context: dict) -> str:
        """
        完整的 AI 診斷流程：構建 Prompt → 呼叫模型 → 回傳結果
        """
        prompt = self.build_prompt(context)
        return self.invoke_model(prompt)

    def _generate_fallback_response(self, prompt: str = "", error_msg: str = "") -> str:
        """
        當 AWS Bedrock 無法連線時的本地 Fallback 回應
        用於 Demo 展示或無 AWS 認證的環境
        """
        # 從 prompt 中提取關鍵資訊（簡易解析）
        lines = prompt.split("\n")
        stock_info = ""
        pnl_info = ""
        for line in lines:
            if "持有股票" in line:
                stock_info = line.strip("- ").strip()
            if "目前用戶損益" in line:
                pnl_info = line.strip("- ").strip()

        fallback = f"""💛 **AI 投資陪伴教練的溫暖回覆**

---

嗨，感謝你願意對我敞開你的庫存。我看到了你的持股狀態，讓我從六個維度來陪你聊聊：

**1. 投資風格觀察：** 從你選的標的來看，你偏好穩健型的配息標的，這其實代表你追求的是「長期現金流」而非短期價差。

**2. 資產配置：** 目前看到的是單一持股，建議思考是否有分散到不同產業或資產類別。

**3. 集中風險提醒：** 若此檔佔你總資產比重過高，波動時的心理壓力會放大。

**4. 投資習慣：** 你願意記錄成本和買進時間，這代表你是有紀律的投資人。

**5. 常見錯誤覺察：** 很多人在帳面虧損時會過度關注短期波動，忘記當初買進的理由。

**6. 決策焦慮紓解：** 社群上的多空聲音很容易影響情緒，但記住——連續配息的歷史是最好的安定劑。

---

🛡️ **想開啟「持股防護罩」嗎？** 訂閱個股警示，當買點分位大幅變動或法人異常買賣時，第一時間通知你，讓你不必天天盯盤也能安心持有。

> ⚠️ *（此為 Demo 模式回應，正式版將由 AWS Bedrock Claude 3 提供更精準的個人化診斷）*
"""

        if error_msg:
            fallback += f"\n> 🔧 技術備註：Bedrock 連線狀態 - {error_msg}"

        return fallback


# 單例
_service_instance = None


def get_bedrock_service() -> BedrockService:
    """取得 BedrockService 單例"""
    global _service_instance
    if _service_instance is None:
        _service_instance = BedrockService()
    return _service_instance
