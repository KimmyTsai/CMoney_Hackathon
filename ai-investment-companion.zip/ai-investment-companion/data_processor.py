"""
data_processor.py
-----------------
AI 投資樹洞 - 核心數據處理模組
使用 Pandas 進行 CSV 數據檢索、多空比計算、損益計算
"""

import pandas as pd
import os
from pathlib import Path

# 資料路徑設定
DATA_DIR = Path(__file__).parent.parent / "cmoney-aws-summit-hackathon" / "Delivery_Hackathon_DataPackage_20260624"

# 系統時間基準：2025/12/31
SYSTEM_DATE = "2025-12-31"
SYSTEM_DATE_NO_DASH = "20251231"


class DataProcessor:
    """CMoney 資料處理核心類別"""

    def __init__(self):
        self._wide_table = None
        self._forum_data = None
        self._price_data = None

    @property
    def wide_table(self) -> pd.DataFrame:
        """09_Wide_Table_Summary（每股一列靜態彙總）"""
        if self._wide_table is None:
            filepath = DATA_DIR / "09_Wide_Table_Summary_One_Row_Per_Stock_2025.csv"
            self._wide_table = pd.read_csv(filepath, dtype={"股票代號": str})
        return self._wide_table

    @property
    def forum_data(self) -> pd.DataFrame:
        """10_Forum_Posts_Replies_Daily_Stats（社群每日統計）"""
        if self._forum_data is None:
            filepath = DATA_DIR / "10_Forum_Posts_Replies_Daily_Stats_2025.csv"
            self._forum_data = pd.read_csv(filepath, dtype={"股票代號": str})
        return self._forum_data

    @property
    def price_data(self) -> pd.DataFrame:
        """01_Price_Valuation（行情估值逐日）"""
        if self._price_data is None:
            filepath = DATA_DIR / "01_Price_Valuation_2025.csv"
            self._price_data = pd.read_csv(filepath, dtype={"股票代號": str, "日期": str})
        return self._price_data

    def get_available_stocks(self) -> pd.DataFrame:
        """取得資料庫中所有可查詢的股票清單"""
        df = self.wide_table[["股票代號", "股票名稱", "產業"]].copy()
        df["顯示"] = df["股票代號"] + " " + df["股票名稱"]
        return df.sort_values("股票代號").reset_index(drop=True)

    def get_stock_summary(self, stock_id: str) -> dict:
        """
        從 09_Wide_Table 讀取該股票的靜態彙總數據
        回傳：產業、連續配息年數、買點分位(%)、殖利率(%)、收盤價
        """
        stock_id = str(stock_id).strip()
        row = self.wide_table[self.wide_table["股票代號"] == stock_id]

        if row.empty:
            return None

        row = row.iloc[0]
        return {
            "股票代號": stock_id,
            "股票名稱": row.get("股票名稱", ""),
            "產業": row.get("產業", "未知"),
            "收盤價": self._safe_float(row.get("收盤價")),
            "連續配息年數": self._safe_float(row.get("連續配息年數")),
            "買點分位": self._safe_float(row.get("買點分位(%)")),
            "殖利率": self._safe_float(row.get("殖利率(%)")),
            "本益比": self._safe_float(row.get("本益比(近四季)")),
            "年報酬率": self._safe_float(row.get("年報酬率(%)")),
            "外資持股率": self._safe_float(row.get("外資持股率(%)")),
        }

    def get_forum_sentiment(self, stock_id: str) -> dict:
        """
        從 10_Forum_Posts 讀取 2025/12/31 當天社群情緒
        回傳：發文則數、看多發文、看空發文、多空比
        """
        stock_id = str(stock_id).strip()
        df = self.forum_data
        row = df[(df["股票代號"] == stock_id) & (df["日期"] == SYSTEM_DATE)]

        if row.empty:
            return {
                "發文則數": 0,
                "看多發文": 0,
                "看空發文": 0,
                "多空比": None,
                "回文則數": 0,
            }

        row = row.iloc[0]
        bullish = int(row.get("看多發文", 0))
        bearish = int(row.get("看空發文", 0))

        # 多空比計算：避免除以零
        if bearish > 0:
            sentiment_ratio = round(bullish / bearish, 2)
        elif bullish > 0:
            sentiment_ratio = float("inf")  # 全看多無看空
        else:
            sentiment_ratio = None  # 無多空資料

        return {
            "發文則數": int(row.get("發文則數", 0)),
            "看多發文": bullish,
            "看空發文": bearish,
            "多空比": sentiment_ratio,
            "回文則數": int(row.get("回文則數", 0)),
        }

    def get_closing_price(self, stock_id: str) -> float:
        """
        取得 2025/12/31 收盤價
        優先從 09 寬表取（已是最新一列），備用從 01 逐日表取
        """
        # 先從寬表取
        summary = self.get_stock_summary(stock_id)
        if summary and summary["收盤價"]:
            return summary["收盤價"]

        # 備用：從逐日價格表取
        stock_id = str(stock_id).strip()
        df = self.price_data
        row = df[(df["股票代號"] == stock_id) & (df["日期"] == SYSTEM_DATE_NO_DASH)]
        if not row.empty:
            return self._safe_float(row.iloc[0].get("收盤價"))

        return None

    def calculate_pnl(self, stock_id: str, cost: float) -> dict:
        """
        計算用戶損益
        損益(%) = ((收盤價 - 買進成本) / 買進成本) * 100
        """
        closing_price = self.get_closing_price(stock_id)
        if closing_price is None or cost <= 0:
            return {"損益百分比": None, "收盤價": closing_price}

        pnl_pct = round(((closing_price - cost) / cost) * 100, 2)
        return {
            "損益百分比": pnl_pct,
            "收盤價": closing_price,
        }

    def build_ai_context(self, stock_id: str, cost: float, shares: int, buy_date: str = "") -> dict:
        """
        整合所有數據，打包成給 AI 的完整上下文
        """
        summary = self.get_stock_summary(stock_id)
        if summary is None:
            return None

        sentiment = self.get_forum_sentiment(stock_id)
        pnl = self.calculate_pnl(stock_id, cost)

        context = {
            "股票代號": stock_id,
            "股票名稱": summary["股票名稱"],
            "產業": summary["產業"],
            "買進成本": cost,
            "持有股數": shares,
            "買進日期": buy_date,
            "收盤價": pnl["收盤價"],
            "損益百分比": pnl["損益百分比"],
            "買點分位": summary["買點分位"],
            "連續配息年數": summary["連續配息年數"],
            "殖利率": summary["殖利率"],
            "本益比": summary["本益比"],
            "年報酬率": summary["年報酬率"],
            "發文則數": sentiment["發文則數"],
            "看多發文": sentiment["看多發文"],
            "看空發文": sentiment["看空發文"],
            "多空比": sentiment["多空比"],
            "回文則數": sentiment["回文則數"],
        }
        return context

    @staticmethod
    def _safe_float(value) -> float:
        """安全轉換為浮點數，處理空值與非數字"""
        try:
            if pd.isna(value):
                return None
            return float(value)
        except (ValueError, TypeError):
            return None


# 單例模式供全域使用
_processor_instance = None


def get_processor() -> DataProcessor:
    """取得 DataProcessor 單例"""
    global _processor_instance
    if _processor_instance is None:
        _processor_instance = DataProcessor()
    return _processor_instance
